﻿using System.Data.SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficeOpenXml;

namespace ExportReturnAndCompareDataExcel
{
    internal class dbInit
    {
        private SQLiteConnection conn;
        private SQLiteCommand cmd;
        private string dbPath = "Data Source = DB.s3db";
        public dbInit()
        {
            conn = new SQLiteConnection(dbPath);
        }

        public List<string[]> RetrieveInformationFromDB(int pagingForCycleIndex)
        {
            List<string[]> listOfRecordsInArrays = new List<string[]>();

            string query = $@"SELECT *  FROM [LineInformation] l LEFT JOIN [Data] d ON l.Id = d.Id WHERE l.Id BETWEEN {pagingForCycleIndex} AND {pagingForCycleIndex + 9}";

            conn.Open();

            SQLiteCommand cmd = new SQLiteCommand(query, conn);
            SQLiteDataReader reader = cmd.ExecuteReader();

            int index = 0;

            //listOfRecordsInArrays.Add(new string[0]);

            while (reader.Read())
            {
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    if (i == 0)
                    {
                        listOfRecordsInArrays.Add(new string[reader.FieldCount]);
                    }

                    if (Convert.IsDBNull(reader[i]))
                    {
                        listOfRecordsInArrays[index][i] = "N/A";
                        continue;
                    }

                    listOfRecordsInArrays[index][i] = reader.GetString(i);
                }

                index++;
            }

            listOfRecordsInArrays.Insert(0, new string[0]);

            conn.Close();

            return listOfRecordsInArrays;
        }

        public void SubmitInformation(List<List<string>> info)
        {
            conn.Open();

            foreach (var item in info)
            {
                cmd = new SQLiteCommand("insert into LineInformation(PCT, LineName, Zone, WorkPlace, RealWorkPlace, AreaBefore) values(@PCT, @lineName, @zone, @workplace, @realWorkPlace, @areaBefore)", conn);

                cmd.Parameters.AddWithValue("PCT", int.Parse(item[0]));
                cmd.Parameters.AddWithValue("lineName", item[1]);
                cmd.Parameters.AddWithValue("zone", item[2] == null ? String.Empty : item[2]);
                cmd.Parameters.AddWithValue("workplace", item[3] == String.Empty ? 0 : int.Parse(item[3]));
                cmd.Parameters.AddWithValue("realWorkPlace", item[4] == String.Empty ? 0 : int.Parse(item[4]));
                cmd.Parameters.AddWithValue("areaBefore", item[5] == String.Empty ? 0 : double.Parse(item[5]));

                cmd.ExecuteNonQuery();
            }

            conn.Close();
        }

        public void DataInsert()
        {
            conn.Open();

            string query = $@"SELECT *  FROM LineInformation";
            SQLiteCommand cmd = new SQLiteCommand(query, conn);

            SQLiteDataReader reader = cmd.ExecuteReader();

            using (reader)
            {
                while (reader.Read())
                {
                    string lineName = reader.GetString(2);   // get current row cell line name on index 2

                    if (lineName == "Any")
                        break;

                    SQLiteCommand getId = new SQLiteCommand($"SELECT Id FROM LineInformation WHERE LineName = @lineName", conn); // rtrieving PK ID from main table line info through line name(unique value) which is needed to make the conection with fk
                    getId.Parameters.AddWithValue("lineName", lineName);
                    long id = (long)getId.ExecuteScalar(); // retrives first value from current row which will be one value ony anyways = id number

                    List<double> yearsForReader = GetYearInfoFromExcel(lineName); // retrieving year values from excel table through line name > 4 indexes > 4 years

                    for (int i = 0; i < yearsForReader.Count; i++)
                    {
                        int yearToInsert = 2019 + i;

                        SQLiteCommand cmd2 = new SQLiteCommand($"INSERT INTO Data(Year, AreaDouble, LineId) VALUES (@yearToInsert, @yearsForReader, @id)", conn); // inserts pk of LineInfo as fk on Data table
                        cmd2.Parameters.AddWithValue("yearToInsert", yearToInsert);
                        cmd2.Parameters.AddWithValue("yearsForReader", yearsForReader[i]);
                        cmd2.Parameters.AddWithValue("id", id);
                        cmd2.ExecuteNonQuery();
                    }


                    //int yearListIndex = 0; // year value holder iterator
                    //foreach (var year in yearsForReader) // for each year in the current LineInformation Id checks if year value is added or not
                    //{
                    //    if (yearListIndex == 4)
                    //    break;

                    //    SQLiteCommand cmd2 = new SQLiteCommand($"INSERT INTO Data(Year, LineId) VALUES ({}, {id})", conn); // inserts pk of LineInfo as fk on Data table
                    //    cmd2.ExecuteNonQuery();



                        //SQLiteCommand checkYear = new SQLiteCommand($"SELECT 1 FROM Data WHERE LineId = {id} AND Year = {2019 + yearListIndex}", conn); // picks the already existing record int eh data table and the lowest year

                        //string queryForUpdate = string.Empty; // query string which decides what will be done if data exists or not
                        //SQLiteCommand setYear = null;

                        //var checker = checkYear.ExecuteScalar();

                        //if (checker == null) // if the year doesnt exist as a value it is being inserted
                        //{
                        //    queryForUpdate = $"UPDATE Data SET Year = {2019 + yearListIndex} WHERE LineId = {id}";
                        //    setYear = new SQLiteCommand(queryForUpdate, conn);
                        //    setYear.ExecuteNonQuery();
                        //}

                        ////after year exist check the specified value is inserted om the areadouble in the data table with the specified id and year

                        //int yearInQuery = 2019 + yearListIndex;

                        //queryForUpdate = $"UPDATE Data SET AreaDouble = @yearsForReader WHERE Year = @yearInQuery AND LineId = {id}";
                        //setYear = new SQLiteCommand(queryForUpdate, conn);
                        
                        //setYear.Parameters.AddWithValue("yearsForReader", yearsForReader[yearListIndex]);
                        //setYear.Parameters.AddWithValue("yearInQuery", yearInQuery);
                        //setYear.ExecuteNonQuery();

                    //    yearListIndex++;
                    //}
                }
            }

            conn.Close();
        }
        // UPDATE Data SET AreaDouble = 100 WHERE Year = 2022 AND Id = 1                      SQL UPDATE QUERY

        public List<double> GetYearInfoFromExcel(string lineName) 
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            FileInfo fi = new FileInfo(@"C:\Users\stoyanovk\Desktop\All lines with areas.xlsx"); // excel connection established

            using (ExcelPackage excelPackage = new ExcelPackage(fi))
            {
                ExcelWorksheet namedWorksheet = excelPackage.Workbook.Worksheets["ALL LINES"]; // choosin excel sheet with specified name

                int index = 3; // row indexator in excel starts from 3 because the needed data begins from there
                
                List<double> fourYearResult = new List<double>(); // year value container initialisation

                foreach (var item in namedWorksheet.Rows)  // iteration thrugh all rows on the excel sheet
                {

                    if (namedWorksheet.Cells[$"B{index}"].Value.ToString() == "All") // (needs refactoring) ends at end row whose value on B cell is "any"(final row)
                    {
                        break;
                    }

                    if (namedWorksheet.Cells[$"C{index}"].Value.ToString() == lineName) // when row with specified name is found iteration through the 4 cells on the current row which hold the years is started
                    {
                        char charLead = (char)72;  // ascii characted from which 2019 starts (H column in excel)
                        foreach (var col in item) // iterates through every column in the row
                        {
                            if (charLead == 76) // when row L is reached the cycle is interrupted
                            {
                                break;
                            }
                                             // example : charlead(H) - index(3) hold value 75.96
                            if (namedWorksheet.Cells[$"{charLead}{index}"].Value == null) // if the value at the specified cell is null assigns zero to the concrete list index
                            {
                                fourYearResult.Add(0);
                            }
                            else // if the cell at the specified column holds value the value it is inserted in the list
                            {
                                fourYearResult.Add((double)namedWorksheet.Cells[$"{charLead}{index}"].Value);
                            }
                            charLead++; // increases the ascii char value by one to go to the next column
                        }
                        return fourYearResult; // returns list that holds year info                        
                    }

                    index++;
                }

                return null;
            }
        }
        //SELECT Id FROM LineInformation WHERE LineName = 'CP Witol 1'




        //private List<string[]> RetrieveInformationAboutLineId(int pagingForCycleIndex)
        //{
        //    List<string[]> listOfRecordsInArrays = new List<string[]>();

        //    string query = $@"SELECT *  FROM [LineInformation] l LEFT JOIN [Data] d ON l.Id = d.Id WHERE l.Id BETWEEN {pagingForCycleIndex} AND {pagingForCycleIndex + 9}";

        //    conn.Open();

        //    SQLiteCommand cmd = new SQLiteCommand(query, conn);
        //    SQLiteDataReader reader = cmd.ExecuteReader();
        //}

        //public List<string[]> RetrieveInformationFromDB(int pagingForCycleIndex)
        //{
        //    List<string[]> listOfRecordsInArrays = new List<string[]>();

        //    string query = $@"SELECT *  FROM [LineInformation] l LEFT JOIN [Data] d ON l.Id = d.Id WHERE l.Id BETWEEN {pagingForCycleIndex} AND {pagingForCycleIndex + 9}";

        //    conn.Open();

        //    SQLiteCommand cmd = new SQLiteCommand(query, conn);
        //    SQLiteDataReader reader = cmd.ExecuteReader();
        //}
    }
}
