﻿// See https://aka.ms/new-console-template for more information

using ExcelDataReader;
using OfficeOpenXml;
using System.Text;
using System.Collections.Generic;
using ExportReturnAndCompareDataExcel;
//System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);



dbInit db = new dbInit();

db.DataInsert();






//List<string> data = new List<string>();


//ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

//FileInfo fi = new FileInfo(@"C:\Users\stoyanovk\Desktop\All lines with areas.xlsx");
////FileInfo fi = new FileInfo(@"C:\Users\stoyanovk\Documents\Customer_orders_01062022.xlsx");

//using (ExcelPackage excelPackage = new ExcelPackage(fi))
//{
//    //Get a WorkSheet by index. Note that EPPlus indexes are base 1, not base 0!
//   // ExcelWorksheet firstWorksheet = excelPackage.Workbook.Worksheets[1];
    
//    //Get a WorkSheet by name. If the worksheet doesn't exist, throw an exeption
//    ExcelWorksheet namedWorksheet = excelPackage.Workbook.Worksheets["ALL LINES"];

//    //If you don't know if a worksheet exists, you could use LINQ,
//    //So it doesn't throw an exception, but return null in case it doesn't find it
//    //ExcelWorksheet anotherWorksheet =
//    //    excelPackage.Workbook.Worksheets.FirstOrDefault(x => x.Name == "SomeWorksheet");

//    int index = 3;
//    int listIndex = 0;
//    List<List<string>> info = new List<List<string>>();
//    dbInit db = new dbInit();   //db instantiation

//    //Get the content from cells A1 and B1 as string, in two different notations
//    foreach (var item in namedWorksheet.Rows)
//    {

//        if (namedWorksheet.Cells[$"B{index}"].Value.ToString() == "All")
//        {
//            break;
//        }
//        info.Add(new List<string>());

//        char charLead = (char)66;
//        foreach (var col in item)
//        {
//            if (charLead == 72)
//            {
//                break;
//            }
//            if (namedWorksheet.Cells[$"{charLead}{index}"].Value == null)
//            {
//                info[listIndex].Add(string.Empty);
//                charLead++;

//                continue;
//            }

//            info[listIndex].Add(namedWorksheet.Cells[$"{charLead}{index}"].Value.ToString());
//            charLead++;
//        }

        

//        listIndex++;
//        index++;

//    }

//    db.SubmitInformation(info);
    
    //string valA1 = namedWorksheet.Cells["A1"].Value.ToString();
    //string valB1 = namedWorksheet.Cells[1, 2].Value.ToString();

    //Save your file
    //excelPackage.Save();
//}